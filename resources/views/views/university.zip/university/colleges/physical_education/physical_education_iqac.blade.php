@extends('layouts.university.colleges.physical_education_with_sidebar')
@section('content')

    <div class="main-content">
        <div class="container">
            <h1 class="tmu-text-primary tmu-page-heading"><span> Internal Quality </span><span> Assurance Cell</span></h1>
            <div class="container">
            <div class="row mb-3">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th class="text-center fw-bold"> Data Will be updated Soon! </th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
            </div>
        </div>
    </div>
    <!-- Bootstrap JS and dependencies -->
</div>

@endsection