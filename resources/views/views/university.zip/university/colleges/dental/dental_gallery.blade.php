@extends('layouts.university.colleges.dental_with_sidebar')
@section('content')

<div class="main-content mt-3 mt-sm-0 pt-2 pt-sm-5">
    <div class="container">
        <h1 class="tmu-text-primary tmu-page-heading mb-2 mt-2"><span>College </span><span> Gallery</span></h1>
        <div class="row">
            <div class="main-content mt-3 mt-sm-0 pt-2 pt-sm-5">
                <div class="container">
                    <div class="row justify-content-center gutter-10" data-lightbox="gallery">
                    <div class="col-md-3 col-sm-6  ">
                            <div class="position-relative">
                                <img class="d-block w-100" src="{{asset('/assets/img/gallery/collegegallery/dental/1.jpg')}}"
                                    alt="Gallery Thumb 2">
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark justify-content-end align-items-end"
                                        data-hover-animate="fadeIn">
                                        <a href="{{asset('/assets/img/gallery/collegegallery/dental/1.jpg')}}"
                                            class="overlay-trigger-icon size-sm bg-light text-dark"
                                            data-hover-animate="fadeInDownSmall"
                                            data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350"
                                            data-lightbox="gallery-item"><i
                                                class="uil uil-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6  ">
                            <div class="position-relative">
                                <img class="d-block w-100" src="{{asset('/assets/img/gallery/collegegallery/dental/2.jpg')}}"
                                    alt="Gallery Thumb 2">
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark justify-content-end align-items-end"
                                        data-hover-animate="fadeIn">
                                        <a href="{{asset('/assets/img/gallery/collegegallery/dental/2.jpg')}}"
                                            class="overlay-trigger-icon size-sm bg-light text-dark"
                                            data-hover-animate="fadeInDownSmall"
                                            data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350"
                                            data-lightbox="gallery-item"><i
                                                class="uil uil-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6  ">
                            <div class="position-relative">
                                <img class="d-block w-100" src="{{asset('/assets/img/gallery/collegegallery/dental/3.jpg')}}"
                                    alt="Gallery Thumb 2">
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark justify-content-end align-items-end"
                                        data-hover-animate="fadeIn">
                                        <a href="{{asset('/assets/img/gallery/collegegallery/dental/3.jpg')}}"
                                            class="overlay-trigger-icon size-sm bg-light text-dark"
                                            data-hover-animate="fadeInDownSmall"
                                            data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350"
                                            data-lightbox="gallery-item"><i
                                                class="uil uil-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6  ">
                            <div class="position-relative">
                                <img class="d-block w-100" src="{{asset('/assets/img/gallery/collegegallery/dental/4.jpg')}}"
                                    alt="Gallery Thumb 2">
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark justify-content-end align-items-end"
                                        data-hover-animate="fadeIn">
                                        <a href="{{asset('/assets/img/gallery/collegegallery/dental/4.jpg')}}"
                                            class="overlay-trigger-icon size-sm bg-light text-dark"
                                            data-hover-animate="fadeInDownSmall"
                                            data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350"
                                            data-lightbox="gallery-item"><i
                                                class="uil uil-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6  ">
                            <div class="position-relative">
                                <img class="d-block w-100" src="{{asset('/assets/img/gallery/collegegallery/dental/5.jpg')}}"
                                    alt="Gallery Thumb 2">
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark justify-content-end align-items-end"
                                        data-hover-animate="fadeIn">
                                        <a href="{{asset('/assets/img/gallery/collegegallery/dental/5.jpg')}}"
                                            class="overlay-trigger-icon size-sm bg-light text-dark"
                                            data-hover-animate="fadeInDownSmall"
                                            data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350"
                                            data-lightbox="gallery-item"><i
                                                class="uil uil-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6  ">
                            <div class="position-relative">
                                <img class="d-block w-100" src="{{asset('/assets/img/gallery/collegegallery/dental/6.jpg')}}"
                                    alt="Gallery Thumb 2">
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark justify-content-end align-items-end"
                                        data-hover-animate="fadeIn">
                                        <a href="{{asset('/assets/img/gallery/collegegallery/dental/6.jpg')}}"
                                            class="overlay-trigger-icon size-sm bg-light text-dark"
                                            data-hover-animate="fadeInDownSmall"
                                            data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350"
                                            data-lightbox="gallery-item"><i
                                                class="uil uil-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6  ">
                            <div class="position-relative">
                                <img class="d-block w-100" src="{{asset('/assets/img/gallery/collegegallery/dental/7.jpg')}}"
                                    alt="Gallery Thumb 2">
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark justify-content-end align-items-end"
                                        data-hover-animate="fadeIn">
                                        <a href="{{asset('/assets/img/gallery/collegegallery/dental/7.jpg')}}"
                                            class="overlay-trigger-icon size-sm bg-light text-dark"
                                            data-hover-animate="fadeInDownSmall"
                                            data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350"
                                            data-lightbox="gallery-item"><i
                                                class="uil uil-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6  ">
                            <div class="position-relative">
                                <img class="d-block w-100" src="{{asset('/assets/img/gallery/collegegallery/dental/8.jpg')}}"
                                    alt="Gallery Thumb 2">
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark justify-content-end align-items-end"
                                        data-hover-animate="fadeIn">
                                        <a href="{{asset('/assets/img/gallery/collegegallery/dental/8.jpg')}}"
                                            class="overlay-trigger-icon size-sm bg-light text-dark"
                                            data-hover-animate="fadeInDownSmall"
                                            data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350"
                                            data-lightbox="gallery-item"><i
                                                class="uil uil-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6  ">
                            <div class="position-relative">
                                <img class="d-block w-100" src="{{asset('/assets/img/gallery/collegegallery/dental/9.jpg')}}"
                                    alt="Gallery Thumb 2">
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark justify-content-end align-items-end"
                                        data-hover-animate="fadeIn">
                                        <a href="{{asset('/assets/img/gallery/collegegallery/dental/9.jpg')}}"
                                            class="overlay-trigger-icon size-sm bg-light text-dark"
                                            data-hover-animate="fadeInDownSmall"
                                            data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350"
                                            data-lightbox="gallery-item"><i
                                                class="uil uil-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6  ">
                            <div class="position-relative">
                                <img class="d-block w-100" src="{{asset('/assets/img/gallery/collegegallery/dental/10.jpg')}}"
                                    alt="Gallery Thumb 2">
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark justify-content-end align-items-end"
                                        data-hover-animate="fadeIn">
                                        <a href="{{asset('/assets/img/gallery/collegegallery/dental/10.jpg')}}"
                                            class="overlay-trigger-icon size-sm bg-light text-dark"
                                            data-hover-animate="fadeInDownSmall"
                                            data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350"
                                            data-lightbox="gallery-item"><i
                                                class="uil uil-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6  ">
                            <div class="position-relative">
                                <img class="d-block w-100" src="{{asset('/assets/img/gallery/collegegallery/dental/11.jpg')}}"
                                    alt="Gallery Thumb 2">
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark justify-content-end align-items-end"
                                        data-hover-animate="fadeIn">
                                        <a href="{{asset('/assets/img/gallery/collegegallery/dental/11.jpg')}}"
                                            class="overlay-trigger-icon size-sm bg-light text-dark"
                                            data-hover-animate="fadeInDownSmall"
                                            data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350"
                                            data-lightbox="gallery-item"><i
                                                class="uil uil-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6  ">
                            <div class="position-relative">
                                <img class="d-block w-100" src="{{asset('/assets/img/gallery/collegegallery/dental/12.jpg')}}"
                                    alt="Gallery Thumb 2">
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark justify-content-end align-items-end"
                                        data-hover-animate="fadeIn">
                                        <a href="{{asset('/assets/img/gallery/collegegallery/dental/12.jpg')}}"
                                            class="overlay-trigger-icon size-sm bg-light text-dark"
                                            data-hover-animate="fadeInDownSmall"
                                            data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350"
                                            data-lightbox="gallery-item"><i
                                                class="uil uil-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6  ">
                            <div class="position-relative">
                                <img class="d-block w-100" src="{{asset('/assets/img/gallery/collegegallery/dental/13.jpg')}}"
                                    alt="Gallery Thumb 2">
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark justify-content-end align-items-end"
                                        data-hover-animate="fadeIn">
                                        <a href="{{asset('/assets/img/gallery/collegegallery/dental/13.jpg')}}"
                                            class="overlay-trigger-icon size-sm bg-light text-dark"
                                            data-hover-animate="fadeInDownSmall"
                                            data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350"
                                            data-lightbox="gallery-item"><i
                                                class="uil uil-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6  ">
                            <div class="position-relative">
                                <img class="d-block w-100" src="{{asset('/assets/img/gallery/collegegallery/dental/14.jpg')}}"
                                    alt="Gallery Thumb 2">
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark justify-content-end align-items-end"
                                        data-hover-animate="fadeIn">
                                        <a href="{{asset('/assets/img/gallery/collegegallery/dental/14.jpg')}}"
                                            class="overlay-trigger-icon size-sm bg-light text-dark"
                                            data-hover-animate="fadeInDownSmall"
                                            data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350"
                                            data-lightbox="gallery-item"><i
                                                class="uil uil-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6  ">
                            <div class="position-relative">
                                <img class="d-block w-100" src="{{asset('/assets/img/gallery/collegegallery/dental/15.jpg')}}"
                                    alt="Gallery Thumb 2">
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark justify-content-end align-items-end"
                                        data-hover-animate="fadeIn">
                                        <a href="{{asset('/assets/img/gallery/collegegallery/dental/15.jpg')}}"
                                            class="overlay-trigger-icon size-sm bg-light text-dark"
                                            data-hover-animate="fadeInDownSmall"
                                            data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350"
                                            data-lightbox="gallery-item"><i
                                                class="uil uil-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6  ">
                            <div class="position-relative">
                                <img class="d-block w-100" src="{{asset('/assets/img/gallery/collegegallery/dental/16.jpg')}}"
                                    alt="Gallery Thumb 2">
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark justify-content-end align-items-end"
                                        data-hover-animate="fadeIn">
                                        <a href="{{asset('/assets/img/gallery/collegegallery/dental/16.jpg')}}"
                                            class="overlay-trigger-icon size-sm bg-light text-dark"
                                            data-hover-animate="fadeInDownSmall"
                                            data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350"
                                            data-lightbox="gallery-item"><i
                                                class="uil uil-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6  ">
                            <div class="position-relative">
                                <img class="d-block w-100" src="{{asset('/assets/img/gallery/collegegallery/dental/17.jpg')}}"
                                    alt="Gallery Thumb 2">
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark justify-content-end align-items-end"
                                        data-hover-animate="fadeIn">
                                        <a href="{{asset('/assets/img/gallery/collegegallery/dental/17.jpg')}}"
                                            class="overlay-trigger-icon size-sm bg-light text-dark"
                                            data-hover-animate="fadeInDownSmall"
                                            data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350"
                                            data-lightbox="gallery-item"><i
                                                class="uil uil-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6  ">
                            <div class="position-relative">
                                <img class="d-block w-100" src="{{asset('/assets/img/gallery/collegegallery/dental/18.jpg')}}"
                                    alt="Gallery Thumb 2">
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark justify-content-end align-items-end"
                                        data-hover-animate="fadeIn">
                                        <a href="{{asset('/assets/img/gallery/collegegallery/dental/18.jpg')}}"
                                            class="overlay-trigger-icon size-sm bg-light text-dark"
                                            data-hover-animate="fadeInDownSmall"
                                            data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350"
                                            data-lightbox="gallery-item"><i
                                                class="uil uil-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6  ">
                            <div class="position-relative">
                                <img class="d-block w-100" src="{{asset('/assets/img/gallery/collegegallery/dental/19.jpg')}}"
                                    alt="Gallery Thumb 2">
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark justify-content-end align-items-end"
                                        data-hover-animate="fadeIn">
                                        <a href="{{asset('/assets/img/gallery/collegegallery/dental/19.jpg')}}"
                                            class="overlay-trigger-icon size-sm bg-light text-dark"
                                            data-hover-animate="fadeInDownSmall"
                                            data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350"
                                            data-lightbox="gallery-item"><i
                                                class="uil uil-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6  ">
                            <div class="position-relative">
                                <img class="d-block w-100" src="{{asset('/assets/img/gallery/collegegallery/dental/20.jpg')}}"
                                    alt="Gallery Thumb 2">
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark justify-content-end align-items-end"
                                        data-hover-animate="fadeIn">
                                        <a href="{{asset('/assets/img/gallery/collegegallery/dental/20.jpg')}}"
                                            class="overlay-trigger-icon size-sm bg-light text-dark"
                                            data-hover-animate="fadeInDownSmall"
                                            data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350"
                                            data-lightbox="gallery-item"><i
                                                class="uil uil-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6  ">
                            <div class="position-relative">
                                <img class="d-block w-100" src="{{asset('/assets/img/gallery/collegegallery/dental/21.jpg')}}"
                                    alt="Gallery Thumb 2">
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark justify-content-end align-items-end"
                                        data-hover-animate="fadeIn">
                                        <a href="{{asset('/assets/img/gallery/collegegallery/dental/21.jpg')}}"
                                            class="overlay-trigger-icon size-sm bg-light text-dark"
                                            data-hover-animate="fadeInDownSmall"
                                            data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350"
                                            data-lightbox="gallery-item"><i
                                                class="uil uil-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6  ">
                            <div class="position-relative">
                                <img class="d-block w-100" src="{{asset('/assets/img/gallery/collegegallery/dental/22.jpg')}}"
                                    alt="Gallery Thumb 2">
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark justify-content-end align-items-end"
                                        data-hover-animate="fadeIn">
                                        <a href="{{asset('/assets/img/gallery/collegegallery/dental/22.jpg')}}"
                                            class="overlay-trigger-icon size-sm bg-light text-dark"
                                            data-hover-animate="fadeInDownSmall"
                                            data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350"
                                            data-lightbox="gallery-item"><i
                                                class="uil uil-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6  ">
                            <div class="position-relative">
                                <img class="d-block w-100" src="{{asset('/assets/img/gallery/collegegallery/dental/23.jpg')}}"
                                    alt="Gallery Thumb 2">
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark justify-content-end align-items-end"
                                        data-hover-animate="fadeIn">
                                        <a href="{{asset('/assets/img/gallery/collegegallery/dental/23.jpg')}}"
                                            class="overlay-trigger-icon size-sm bg-light text-dark"
                                            data-hover-animate="fadeInDownSmall"
                                            data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350"
                                            data-lightbox="gallery-item"><i
                                                class="uil uil-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6  ">
                            <div class="position-relative">
                                <img class="d-block w-100" src="{{asset('/assets/img/gallery/collegegallery/dental/24.jpg')}}"
                                    alt="Gallery Thumb 2">
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark justify-content-end align-items-end"
                                        data-hover-animate="fadeIn">
                                        <a href="{{asset('/assets/img/gallery/collegegallery/dental/24.jpg')}}"
                                            class="overlay-trigger-icon size-sm bg-light text-dark"
                                            data-hover-animate="fadeInDownSmall"
                                            data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350"
                                            data-lightbox="gallery-item"><i
                                                class="uil uil-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6  ">
                            <div class="position-relative">
                                <img class="d-block w-100" src="{{asset('/assets/img/gallery/collegegallery/dental/25.jpg')}}"
                                    alt="Gallery Thumb 2">
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark justify-content-end align-items-end"
                                        data-hover-animate="fadeIn">
                                        <a href="{{asset('/assets/img/gallery/collegegallery/dental/25.jpg')}}"
                                            class="overlay-trigger-icon size-sm bg-light text-dark"
                                            data-hover-animate="fadeInDownSmall"
                                            data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350"
                                            data-lightbox="gallery-item"><i
                                                class="uil uil-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6  ">
                            <div class="position-relative">
                                <img class="d-block w-100" src="{{asset('/assets/img/gallery/collegegallery/dental/26.jpg')}}"
                                    alt="Gallery Thumb 2">
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark justify-content-end align-items-end"
                                        data-hover-animate="fadeIn">
                                        <a href="{{asset('/assets/img/gallery/collegegallery/dental/26.jpg')}}"
                                            class="overlay-trigger-icon size-sm bg-light text-dark"
                                            data-hover-animate="fadeInDownSmall"
                                            data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350"
                                            data-lightbox="gallery-item"><i
                                                class="uil uil-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6  ">
                            <div class="position-relative">
                                <img class="d-block w-100" src="{{asset('/assets/img/gallery/collegegallery/dental/27.jpg')}}"
                                    alt="Gallery Thumb 2">
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark justify-content-end align-items-end"
                                        data-hover-animate="fadeIn">
                                        <a href="{{asset('/assets/img/gallery/collegegallery/dental/27.jpg')}}"
                                            class="overlay-trigger-icon size-sm bg-light text-dark"
                                            data-hover-animate="fadeInDownSmall"
                                            data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350"
                                            data-lightbox="gallery-item"><i
                                                class="uil uil-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6  ">
                            <div class="position-relative">
                                <img class="d-block w-100" src="{{asset('/assets/img/gallery/collegegallery/dental/28.jpg')}}"
                                    alt="Gallery Thumb 2">
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark justify-content-end align-items-end"
                                        data-hover-animate="fadeIn">
                                        <a href="{{asset('/assets/img/gallery/collegegallery/dental/28.jpg')}}"
                                            class="overlay-trigger-icon size-sm bg-light text-dark"
                                            data-hover-animate="fadeInDownSmall"
                                            data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350"
                                            data-lightbox="gallery-item"><i
                                                class="uil uil-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6  ">
                            <div class="position-relative">
                                <img class="d-block w-100" src="{{asset('/assets/img/gallery/collegegallery/dental/29.jpg')}}"
                                    alt="Gallery Thumb 2">
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark justify-content-end align-items-end"
                                        data-hover-animate="fadeIn">
                                        <a href="{{asset('/assets/img/gallery/collegegallery/dental/29.jpg')}}"
                                            class="overlay-trigger-icon size-sm bg-light text-dark"
                                            data-hover-animate="fadeInDownSmall"
                                            data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350"
                                            data-lightbox="gallery-item"><i
                                                class="uil uil-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6  ">
                            <div class="position-relative">
                                <img class="d-block w-100" src="{{asset('/assets/img/gallery/collegegallery/dental/30.jpg')}}"
                                    alt="Gallery Thumb 2">
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark justify-content-end align-items-end"
                                        data-hover-animate="fadeIn">
                                        <a href="{{asset('/assets/img/gallery/collegegallery/dental/30.jpg')}}"
                                            class="overlay-trigger-icon size-sm bg-light text-dark"
                                            data-hover-animate="fadeInDownSmall"
                                            data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350"
                                            data-lightbox="gallery-item"><i
                                                class="uil uil-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6  ">
                            <div class="position-relative">
                                <img class="d-block w-100" src="{{asset('/assets/img/gallery/collegegallery/dental/31.jpg')}}"
                                    alt="Gallery Thumb 2">
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark justify-content-end align-items-end"
                                        data-hover-animate="fadeIn">
                                        <a href="{{asset('/assets/img/gallery/collegegallery/dental/31.jpg')}}"
                                            class="overlay-trigger-icon size-sm bg-light text-dark"
                                            data-hover-animate="fadeInDownSmall"
                                            data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350"
                                            data-lightbox="gallery-item"><i
                                                class="uil uil-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6  ">
                            <div class="position-relative">
                                <img class="d-block w-100" src="{{asset('/assets/img/gallery/collegegallery/dental/32.jpg')}}"
                                    alt="Gallery Thumb 2">
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark justify-content-end align-items-end"
                                        data-hover-animate="fadeIn">
                                        <a href="{{asset('/assets/img/gallery/collegegallery/dental/32.jpg')}}"
                                            class="overlay-trigger-icon size-sm bg-light text-dark"
                                            data-hover-animate="fadeInDownSmall"
                                            data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350"
                                            data-lightbox="gallery-item"><i
                                                class="uil uil-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6  ">
                            <div class="position-relative">
                                <img class="d-block w-100" src="{{asset('/assets/img/gallery/collegegallery/dental/33.jpg')}}"
                                    alt="Gallery Thumb 2">
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark justify-content-end align-items-end"
                                        data-hover-animate="fadeIn">
                                        <a href="{{asset('/assets/img/gallery/collegegallery/dental/33.jpg')}}"
                                            class="overlay-trigger-icon size-sm bg-light text-dark"
                                            data-hover-animate="fadeInDownSmall"
                                            data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350"
                                            data-lightbox="gallery-item"><i
                                                class="uil uil-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6  ">
                            <div class="position-relative">
                                <img class="d-block w-100" src="{{asset('/assets/img/gallery/collegegallery/dental/34.jpg')}}"
                                    alt="Gallery Thumb 2">
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark justify-content-end align-items-end"
                                        data-hover-animate="fadeIn">
                                        <a href="{{asset('/assets/img/gallery/collegegallery/dental/34.jpg')}}"
                                            class="overlay-trigger-icon size-sm bg-light text-dark"
                                            data-hover-animate="fadeInDownSmall"
                                            data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350"
                                            data-lightbox="gallery-item"><i
                                                class="uil uil-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6  ">
                            <div class="position-relative">
                                <img class="d-block w-100" src="{{asset('/assets/img/gallery/collegegallery/dental/35.jpg')}}"
                                    alt="Gallery Thumb 2">
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark justify-content-end align-items-end"
                                        data-hover-animate="fadeIn">
                                        <a href="{{asset('/assets/img/gallery/collegegallery/dental/35.jpg')}}"
                                            class="overlay-trigger-icon size-sm bg-light text-dark"
                                            data-hover-animate="fadeInDownSmall"
                                            data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350"
                                            data-lightbox="gallery-item"><i
                                                class="uil uil-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6  ">
                            <div class="position-relative">
                                <img class="d-block w-100" src="{{asset('/assets/img/gallery/collegegallery/dental/36.jpg')}}"
                                    alt="Gallery Thumb 2">
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark justify-content-end align-items-end"
                                        data-hover-animate="fadeIn">
                                        <a href="{{asset('/assets/img/gallery/collegegallery/dental/36.jpg')}}"
                                            class="overlay-trigger-icon size-sm bg-light text-dark"
                                            data-hover-animate="fadeInDownSmall"
                                            data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350"
                                            data-lightbox="gallery-item"><i
                                                class="uil uil-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6  ">
                            <div class="position-relative">
                                <img class="d-block w-100" src="{{asset('/assets/img/gallery/collegegallery/dental/37.jpg')}}"
                                    alt="Gallery Thumb 2">
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark justify-content-end align-items-end"
                                        data-hover-animate="fadeIn">
                                        <a href="{{asset('/assets/img/gallery/collegegallery/dental/37.jpg')}}"
                                            class="overlay-trigger-icon size-sm bg-light text-dark"
                                            data-hover-animate="fadeInDownSmall"
                                            data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350"
                                            data-lightbox="gallery-item"><i
                                                class="uil uil-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6  ">
                            <div class="position-relative">
                                <img class="d-block w-100" src="{{asset('/assets/img/gallery/collegegallery/dental/38.png')}}"
                                    alt="Gallery Thumb 2">
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark justify-content-end align-items-end"
                                        data-hover-animate="fadeIn">
                                        <a href="{{asset('/assets/img/gallery/collegegallery/dental/38.png')}}"
                                            class="overlay-trigger-icon size-sm bg-light text-dark"
                                            data-hover-animate="fadeInDownSmall"
                                            data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350"
                                            data-lightbox="gallery-item"><i
                                                class="uil uil-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6  ">
                            <div class="position-relative">
                                <img class="d-block w-100" src="{{asset('/assets/img/gallery/collegegallery/dental/39.jpg')}}"
                                    alt="Gallery Thumb 2">
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark justify-content-end align-items-end"
                                        data-hover-animate="fadeIn">
                                        <a href="{{asset('/assets/img/gallery/collegegallery/dental/39.jpg')}}"
                                            class="overlay-trigger-icon size-sm bg-light text-dark"
                                            data-hover-animate="fadeInDownSmall"
                                            data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350"
                                            data-lightbox="gallery-item"><i
                                                class="uil uil-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6  ">
                            <div class="position-relative">
                                <img class="d-block w-100" src="{{asset('/assets/img/gallery/collegegallery/dental/40.jpg')}}"
                                    alt="Gallery Thumb 2">
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark justify-content-end align-items-end"
                                        data-hover-animate="fadeIn">
                                        <a href="{{asset('/assets/img/gallery/collegegallery/dental/40.jpg')}}"
                                            class="overlay-trigger-icon size-sm bg-light text-dark"
                                            data-hover-animate="fadeInDownSmall"
                                            data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350"
                                            data-lightbox="gallery-item"><i
                                                class="uil uil-plus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>
<!-- Bootstrap JS and dependencies -->


@endsection