<div class="main-sidebar" id="main-sidebar">
    <div class="logo">
        <span class="close-btn" id="closeSidebar">&times;</span>
    </div>
    <div class="custom-menu-section">
        <h2 class="fs-16">RDC At A Glance</h2>
        <div class="account-section">
            <a href="/research_development_center.php" class="custom-menu-item active">
                <p>About RDC</p>
            </a>
            <a href="/rdc_faculty_profile.php" class="custom-menu-item">
                <p>Faculty Profile</p>
            </a>
            <a href="/r&d_contactus.php" class="custom-menu-item">
                <p>Contact Us</p>
            </a>
            <a href="/r&d_infrastructure.php" class="custom-menu-item">
                <p>Infrastructure</p>
            </a>
        </div>
         <h2 class="fs-16">Quick Links</h2>
        <div class="account-section">
            <a href="/greviances.php" class="custom-menu-item">
                <p>Greviance Portal</p>
            </a>
            <a href="/disciplinary_rules.php" class="custom-menu-item active">
                <p>Disciplinary Rules</p>
            </a>
            <a href="https://www.tmu.ac.in/pdf/TMU_Admission%20Policy%20&%20Refund%20Policy%20_2024.pdf" class="custom-menu-item">
                <p>Admission Refund policy</p>
            </a>
            <a href="/university_anti_ragging_committee.php" class="custom-menu-item">
                <p>Anti Ragging Committee</p>
            </a>
            <a href="/university_academic_calendar.php" class="custom-menu-item">
                <p>University Academic Calendar</p>
            </a>
            <a href="/nss_aboutus.php" class="custom-menu-item">
                <p>NSS Unit</p>
            </a>
        </div>
    </div>
</div>
<div class="toggle-btn" style="color: #fff;" id="sidebarToggle"><i class="fas fa-bars" style="transform: rotate(90deg);"></i></div> 