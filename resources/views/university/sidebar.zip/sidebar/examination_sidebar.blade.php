<div class="col-sm-3 col-lg-2 sticky-sidebar-wrap pe-5 py-0 py-lg-3 " style="background-color: #55555510;">

    <span class="undernav-locator mb-2 ms-3">
        <span style="color:#fe8d00" ; style="font-size:24px"><a href="/"><i class="fa-solid fa-house"></i></a></span>
        <i class="fa-solid fa-chevron-right" style="color:#fe8d00"></i>
        <span style="color:#001055; font-weight:700;">EXAMINATION SYSTEM</span>
    </span>

    <ul class="list-unstyled items-nav sticky-sidebar shop-filter mt-4 d-none d-sm-block" data-container="#shop">
        <li class="no-divider"><a href="" class="text-dark fw-semibold side-head" data-filter=".sf-new">Examination System</a></li>
        <li><a href="{{route('exam.overview')}}" data-filter=".sf-overview">Overview</a></li>
        <li><a href="{{route('exam.ordinance')}}" data-filter=".sf-ordinance">Examination Ordinance</a></li>
        <li><a href="{{route('exam.syllabus')}}" data-filter=".sf-ordinance">Syllabus</a></li>
        <li><a href="{{route('cbcs.home')}}" data-filter=".sf-credit-system">Choice Based Credit System</a></li>
        <li><a href="https://www.tmu.ac.in/tmu/exam-overview#" data-filter=".sf-datesheet">Examination Datesheet</a></li>
        <li><a href="http://portal2.tmu.ac.in/" data-filter=".sf-online-exam-form">Online Examination Form</a></li>
        <li><a href="https://cvl.nad.co.in/NAD/home.action" data-filter=".sf-nad">NAD</a></li>

        <li>
            <hr>
        </li>
        <li class="no-divider"><a href="" class="text-dark fw-semibold side-head" data-filter=".sf-new">Quick Links</a></li>
        <li><a href="{{route('about.us')}}" data-filter=".sf-about-us">About University</a></li>
        <li><a href="{{route('vision.mission')}}" data-filter=".sf-vision-&-mission">Vision & Mission</a></li>
        <li><a href="{{route('statutory.approvals')}}" data-filter=".sf-statutory-approvals">Statutory Approvals</a></li>
        <li><a href="{{route('awards.and.recognition')}}" data-filter=".sf-awards-recognitions">Rating/Award/<br>Recognition</a></li>
        <li><a href="#" data-filter=".sf-why-tmu">Why Choose TMU?</a></li>
        <li><a href="{{route('university.governance')}}" data-filter=".sf-governance">University Governance</a></li>
        <li><a href="{{route('university.administration')}}" data-filter=".sf-administration">University Administration</a></li>
        <li><a href="#" data-filter=".sf-map-location">Campus Map & Location</a></li>
    </ul>




</div>