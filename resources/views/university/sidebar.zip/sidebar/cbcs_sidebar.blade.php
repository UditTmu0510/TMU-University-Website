<div class="col-12 d-sm-none" style="background-color: #55555510;">
	<span class="undernav-locator mb-2 ms-3 d-none d-sm-block">
		<span style="color:#fe8d00" ; style="font-size:24px"><a href="/"><i class="fa-solid fa-house"></i></a></span>
		<i class="fa-solid fa-chevron-right" style="color:#fe8d00"></i>
        <span style="color:#001055; font-weight:700;">Open Elective Courses</span>
    </span>
    </div>
<div class="col-sm-3 col-lg-2 sticky-sidebar-wrap pe-5 py-0 py-lg-3 order-last order-sm-first mt-5 mt-sm-0" style="background-color: #55555510;">

	<span class="undernav-locator mb-2 ms-3 d-none d-sm-block">
		<span style="color:#fe8d00" ; style="font-size:24px"><a href="/"><i class="fa-solid fa-house"></i></a></span>
		<i class="fa-solid fa-chevron-right" style="color:#fe8d00"></i>
        <span style="color:#001055; font-weight:700;">Open Elective Courses</span>
        </span>

<p class="text-center fs-24 tmu-color mt-3 fw-bold tmu-text-primary d-sm-none">
    <span>Quick </span><span>Links</span>
</p>

    <ul class="list-unstyled items-nav sticky-sidebar shop-filter mt-4 d-none d-sm-block" data-container="#shop">
        <li class="no-divider"><a href="#" class="text-dark fw-semibold side-head" data-filter=".sf-new">Open Elective Courses</a></li>
        <li><a href="{{route('cbcs.home')}}" data-filter=".sf-home">Home</a></li>
        <li><a href="{{route('cbcs.circulars')}}" data-filter=".sf-home">CBCS Circular</a></li>
        <li><a href="{{route('cbcs.nursing')}}" data-filter=".sf-nursing">Nursing</a></li>
        <li><a href="{{route('cbcs.pharmacy')}}" data-filter=".sf-pharmacy">Pharmacy</a></li>
        <li><a href="{{route('cbcs.paramedical')}}" data-filter=".sf-paramedical">Paramedical Sciences</a></li>
        <li><a href="{{route('cbcs.physiotherapy')}}" data-filter=".sf-physiotherapy">Physiotherapy</a></li>
        <li><a href="{{route('cbcs.management')}}" data-filter=".sf-management">Management</a></li>
        <li><a href="{{route('cbcs.law')}}" data-filter=".sf-law-college">Law & Legal Studies</a></li>
        <li><a href="{{route('cbcs.ccsit')}}" data-filter=".sf-ccsit">Computing Sciences & IT</a></li>
        <li><a href="{{route('cbcs.foe')}}" data-filter=".sf-engineering">Engineering</a></li>
        <li><a href="{{route('cbcs.polytechnic')}}" data-filter=".sf-polytechnic">University Polytechnic</a></li>
        <li><a href="{{route('cbcs.education')}}" data-filter=".sf-education-college">Education</a></li>
        <li><a href="{{route('cbcs.agriculture')}}" data-filter=".sf-agriculture-science">Agriculture Sciences</a></li>
    </ul>




</div>