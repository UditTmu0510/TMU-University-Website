<div class="main-sidebar" id="main-sidebar">
    <div class="logo">
        <span class="close-btn" id="closeSidebar">&times;</span>
    </div>
    <div class="custom-menu-section">
        <h2>About College</h2>
        <div class="account-section">
            <a href="/engineering_overview.php" class="custom-menu-item active">
                <p>About Us</p>
            </a>
            <a href="/engineering_highlights.php" class="custom-menu-item">
                <p>College Highlights</p>
            </a>
            <a href="/engineering_principal.php" class="custom-menu-item">
                <p>Principal Desk</p>
            </a>
            <a href="/engineering_gallery.php" class="custom-menu-item">
                <p>Gallery</p>
            </a>
        </div>
        <h2>Academics</h2>
        <div class="account-section">
            <a href="/engineering_syllabus.php" class="custom-menu-item">
                <p>Syllabus</p>
            </a>
            <a href="/engineering_academic_calendar.php" class="custom-menu-item">
                <p>Academic Calendar</p>
            </a>
        </div>
        <h2 style="font-size:16px!important;">Training & Placements</h2>
        <div class="account-section">
            <a href="/engineering_brochure.php" class="custom-menu-item">
                <p>Placement Brochure</p>
            </a>
            <a href="/engineering_corporate_board.php" class="custom-menu-item">
                <p>Corporate Advisory Board</p>
            </a>
            <a href="/engineering_placement_calendar.php" class="custom-menu-item">
                <p>Placement Calendar</p>
            </a>
            <a href="/engineering_placement_news.php" class="custom-menu-item">
                <p>Placement News / Article</p>
            </a>
        </div>
        <h2>Student Corner</h2>
        <div class="account-section">
            <a href="/engineering_timetable.php" class="custom-menu-item ">
                <p>Time Table</p>
            </a>
            <a href="http://library.tmu.ac.in/" class="custom-menu-item">
                <p>Old Exam Papers</p>
            </a>
            <a href="/engineering_project_template.php" target="_blank" class="custom-menu-item">
                <p>Project Template</p>
            </a>
            <a href="/engineering_project_guidelines.php" target="_blank" class="custom-menu-item">
                <p>Project Guidelines</p>
            </a>
            <a href="/engineering_anti_ragging.php" class="custom-menu-item">
                <p>Anti Ragging Committee</p>
            </a>
        </div>
        <h2>Quick Links</h2>
        <div class="account-section">
            <a href="/engineering_financial_statement.php" target="_blank" class="custom-menu-item">
                <p>Audited Financial Statement</p>
            </a>
            <a href="/engineering_contact_us.php" target="_blank" class="custom-menu-item">
                <p>Contact Us</p>
            </a>
            <a href="/engineering_iqac.php" target="_blank" class="custom-menu-item">
                <p>College IQAC</p>
            </a>
        </div>
    </div>

</div>
<div class="toggle-btn" style="color: #fff;" id="sidebarToggle"><i class="fas fa-bars" style="transform: rotate(90deg);"></i></div>